
export enum ProgramLevel {
  UG = 'Undergraduate',
  PG = 'Postgraduate',
  PHD = 'PhD'
}

export interface ProgramData {
  id: string;
  universityName: string;
  country: 'Canada' | 'UK';
  programName: string;
  level: ProgramLevel;
  tuitionFee: string;
  applicationFee: string;
  ieltsScore: string;
  toeflScore: string;
  admissionRequirements: string;
  indianAcademicReq: string; // Specific to CBSE/ICSE/State Boards
  indianScholarships: string; // Scholarships for Indian nationals
  backlogPolicy: string; // Critical for Indian applicants
  deadline: string;
  sourceUrl: string;
}

export interface ScrapingTask {
  university: string;
  country: 'Canada' | 'UK';
  status: 'pending' | 'processing' | 'completed' | 'failed';
  error?: string;
  data?: ProgramData[];
}

export interface DashboardStats {
  totalScraped: number;
  averageTuition: number;
  countriesCount: { [key: string]: number };
}
